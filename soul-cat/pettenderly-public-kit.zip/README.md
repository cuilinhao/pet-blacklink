# Pettenderly — public submission kit

Website: https://pettenderly.com/
Contact: support@soulpaw.art
Prepared: 2026-11-06

- [Product profile](sites/Pettenderly.md) / [JSON](sites/pettenderly.json)
- [English and Chinese copy](copy/submission-copy.md) / [Character counts](copy/snippets.json)
- [Asset sources and dimensions](assets/manifest.json)

Use PNG logos for icon fields, the OG cover for banners, and real screenshots for interface fields. Royal artwork is illustrative, not a verified customer result.

Generation requires paid credits. You & your pet and photo cleanup are beta features. Unknown business facts are blank. No credentials or submission history are included.
